from .noiftimer import Timer, time_it

__version__ = "2.3.1"
# Changelog

## 1.1.0 (2023-03-13)

#### New Features

* add subsecond_resolution flag to current_elapsed_time()
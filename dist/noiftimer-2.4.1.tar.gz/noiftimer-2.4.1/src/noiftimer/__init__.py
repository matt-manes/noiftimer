from .noiftimer import Timer, time_it

__version__ = "2.4.1"

from .noiftimer import Timer, log_time, time_it

__version__ = "2.5.0"
__all__ = ["Timer", "time_it", "log_time"]
